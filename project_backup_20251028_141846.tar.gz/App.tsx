import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import React, { useEffect } from "react";

// 🧩 Komponenter & sidor
import ResetPassword from "@/components/ResetPassword";
import CookieBanner from "@/components/CookieBanner";
import CookiePolicy from "@/pages/CookiePolicy";
import ClearCookies from "@/pages/ClearCookies";
import Privacy from "@/pages/Privacy";
import Index from "@/pages/Index";
import NotFound from "@/pages/NotFound";
import FragorTips from "@/pages/FragorTips";
import AdminPortal from "@/pages/AdminPortal";
import Portal from "@/pages/Portal";

// 💼 Services
import Services from "@/pages/services";
import Forsaljning from "@/pages/services/Forsaljning";
import Stadning from "@/pages/services/Stadning";
import Flytt from "@/pages/services/Flytt";
import TomningBohag from "@/pages/services/TomningBohag";
import Vardering from "@/pages/services/vardering-ai";
import Magasinering from "@/pages/services/Magasinering";
import RadgivningPlanering from "@/pages/services/RadgivningPlanering";

// 🧠 AI-värdering (ny)

const queryClient = new QueryClient();

function App() {
  useEffect(() => {
    // här kan du initiera analytics eller liknande
  }, []);

  return (
    <>
      <CookieBanner />
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <BrowserRouter>
            <Toaster />
            <Sonner />
            <Routes>
              {/* 🌍 Startsida */}
              <Route path="/" element={<Index />} />

              {/* 💼 Tjänster */}
              <Route path="/services" element={<Services />} />
              <Route path="/services/forsaljning" element={<Forsaljning />} />
              <Route path="/services/stadning" element={<Stadning />} />
              <Route path="/services/flytt" element={<Flytt />} />
              <Route path="/services/tomning-bohag" element={<TomningBohag />} />
              <Route path="/services/vardering" element={<Vardering />} />
              <Route path="/services/magasinering" element={<Magasinering />} />
              <Route path="/services/radgivning-planering" element={<RadgivningPlanering />} />

              {/* 🧠 AI Värdering */}
              {/* 🧠 AI Värdering */}
              <Route path="/vardering-ai" element={<Vardering />} />
              {/* 🧑‍💼 Portaler */}
              <Route path="/portal" element={<Portal />} />
              <Route path="/adminportal" element={<AdminPortal />} />

              {/* ❓ Frågor & Policy */}
              <Route path="/fragor-tips" element={<FragorTips />} />
              <Route path="/reset-password" element={<ResetPassword />} />
              <Route path="/cookiepolicy" element={<CookiePolicy />} />
              <Route path="/clearcookies" element={<ClearCookies />} />
              <Route path="/privacy" element={<Privacy />} />

              {/* 🚫 404 */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </QueryClientProvider>
    </>
  );
}

export default App;
